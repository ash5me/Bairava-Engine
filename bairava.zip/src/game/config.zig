//! Game settings: title, window and native view sizes, level path, background color, update
//! rate, and scale mode. Read once at startup. The engine knows nothing else about the game.

const std = @import("std");
const engine = @import("bairava");

/// Window title. The window keeps it as written; frame stats are in the debug overlay (F3).
pub const title: [:0]const u8 = "Semkootru";
/// Window size in pixels at startup. The settings file can change it with `resolution`.
pub const window_w: c_int = 960;
pub const window_h: c_int = 540;
/// Fullscreen and vsync at startup. The settings file can change both.
pub const fullscreen = false;
pub const vsync = true;
/// The settings file, beside the executable. It sets the resolution, fullscreen, vsync, and key
/// bindings. A missing file means these defaults. Copy `settings.txt` there to edit it.
pub const settings_file_name = "settings.txt";
/// The reference view size, in native pixels. At zoom 1 it fits the window on its limiting axis,
/// so the view is exactly this size on that axis. The pixel art is designed at this size.
pub const native_w: u32 = 320;
pub const native_h: u32 = 180;
/// Background color behind the world, as RGB from 0 to 1.
pub const clear_rgb = [3]f32{ 0.2, 0.3, 0.5 };
/// Game logic steps per second. Movement is in pixels per second, so this changes smoothness, not speed.
pub const update_hz: u32 = 60;
/// Starting scale mode. Integer uses evenly sized native pixels and letterboxing; press I to switch to fit,
/// where the native view stretches to fill the window and may introduce uneven pixel boundaries.
pub const scale_mode: engine.ScaleMode = .integer;
/// Renderer backend setting. SDL_GPU is the currently active presentation backend.
/// `.sdl2d` is reserved until the complete 2D resource and sprite path is implemented.
pub const renderer: engine.Renderer = .sdl_gpu;
/// How fast the camera catches up with the player, as a rate per second. Higher is snappier. Zero
/// turns smoothing off, so the camera snaps to the player.
pub const camera_rate: f32 = 10.0;
/// Zoom limits and step. 1 is the normal view. The bounds must include 1, so the reset key lands
/// inside them, and the minimum must be positive, because zoom eases in logarithmic steps.
pub const zoom_min: f32 = 0.5;
pub const zoom_max: f32 = 4.0;
/// Each zoom-in press multiplies the zoom by this. Each zoom-out press divides by it.
pub const zoom_step: f32 = 1.25;
/// How fast the camera eases to a new zoom, per second. Zero snaps.
pub const zoom_rate: f32 = 8.0;
/// Post-processing effects, run in order over the finished world before it is shown. Empty turns them off.
/// To try one, list it, for example `&.{ .vignette }` or `&.{ .grayscale, .vignette }`.
pub const post_effects: []const engine.Effect = &.{};
/// Strengths the effects read: vignette, scanline dim, and grayscale amount, each from 0 to 1. The defaults keep their original look.
pub const post_params: engine.PostParams = engine.default_post_params;
/// The most bytes the texture cache may hold. Zero means no budget. Requested textures are loaded through the cache,
/// so the budget applies to them; direct `acquireTexture` loads count against it too.
pub const texture_budget_bytes: usize = 0;
/// Textures the runtime loads each frame from its preload requests. Zero turns preloading off.
pub const texture_loads_per_frame: usize = 2;

comptime {
    if (!(zoom_min > 0.0 and zoom_min <= 1.0 and zoom_max >= 1.0)) @compileError("zoom bounds must be positive and include 1");
    if (!(zoom_step > 1.0)) @compileError("zoom_step must be greater than 1");
}
/// The texture atlas: one image that holds every sprite, and an index of where each sprite sits in
/// it. `zig build` makes both from the sprite list in build.zig, and installs them beside the
/// executable. Paths are relative to the executable's folder. A sprite the game asks for by name
/// must be in atlas_sprites in build.zig, or the game panics at startup.
pub const atlas_image_path = "assets/atlas.png";
pub const atlas_index_path = "assets/atlas.txt";
/// Generated runtime asset index, including output paths and dependency edges.
pub const asset_index_path = "assets/asset-index.txt";

/// The tile map the game loads at startup, relative to the executable's folder.
pub const level_path = "assets/maps/level1.txt";
/// Game-specific level metadata: the spawn cell, and the entities the level places. See docs/prefabs.md.
pub const level_spawn_path = "assets/maps/level1.spawn";
/// Game-owned prefab definitions: the entity templates that the level metadata places by name.
pub const prefab_path = "assets/prefabs.txt";
/// Versioned, validated sprite animation definitions.
pub const animation_path = "assets/animations/warrior.anim";
pub const machine_path = "assets/animations/warrior.machine";

/// Looping ambience, relative to the executable's folder.
pub const ambient_sound_path = "assets/wind1.wav";

/// The gameplay script, relative to the executable's folder. The asset manifest packages it from
/// `assets/scripts/game.bs`. A missing or broken script is logged, and the game runs without one.
pub const script_path = "assets/scripts/game.bs";
/// Most steps one script call may take before it is stopped, so a loop that never ends can't freeze the game.
pub const script_max_steps: usize = 100_000;

/// The gameplay saves, one file per slot, beside the executable. Each is human-editable JSON with a schema version.
/// Slot 1 is `save.json`, the file older versions wrote, so an existing save still loads. F5 saves to the selected
/// slot, F9 loads it, and Tab or the Saves page selects it. Every name must differ from the others.
pub const save_slot_files = [_][]const u8{ "save.json", "save2.json", "save3.json" };

comptime {
    for (save_slot_files, 0..) |name, index| {
        for (save_slot_files[index + 1 ..]) |other| {
            if (std.mem.eql(u8, name, other)) @compileError("two save slots share the file '" ++ name ++ "'");
        }
    }
}

/// The font for the demo panel: a prebaked `.bfnt` file from the asset manifest, relative to the executable's
/// folder, and its height in native pixels. The UI is drawn at native resolution, so 8 keeps it compact at the
/// 320x180 view. The file must have been baked at exactly this size.
pub const ui_font_path = "assets/ui_font_9px.bfnt";
pub const ui_font_px: f32 = 9;
/// The font for the debug overlay, and its height. This is the engine's single definition (application.zig), so the
/// game and the samples cannot disagree. It is the same 9 px mono atlas as the demo panel. At 7 px mono hinting drops
/// strokes, and at 8 px some glyphs still blur together.
pub const debug_font_path = engine.default_debug_font_path;
pub const debug_font_px: f32 = engine.default_debug_font_px;

/// The log file, written beside the executable and replaced on each run. Null logs to the terminal only.
pub const log_file_name: ?[:0]const u8 = "Semkootru.log";
pub const crash_file_name: ?[:0]const u8 = "Semkootru.crash.txt";
