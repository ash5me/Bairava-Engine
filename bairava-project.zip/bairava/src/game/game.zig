//! Gameplay: the level, the player, the demo panel, and how actions drive them. The engine calls
//! into this file through `init`, `update`, `draw`, and `deinit`, and never looks inside it. Game
//! code imports only the named `bairava` module, so everything the game needs from the platform goes through
//! the engine's `Context`.

const std = @import("std");

const engine = @import("bairava");
const config = @import("config.zig");
const controls = @import("controls.zig");
const Level = @import("level.zig").Level;
const Player = @import("player.zig").Player;
const save_store = @import("save.zig");
const script_host = @import("script_host.zig");
const prefab = @import("prefab.zig");
const level_data = @import("level_data.zig");
const enemy = @import("enemy.zig");

const log = engine.log.scoped("game");

/// Draw order of the panel. Sprites sort by z, so this places the panel above the world and the player.
const ui_z: i32 = 1000;

/// Width of the panel in view pixels. Wide enough for a keybind row: the action's name at the left, its keys at the right.
const panel_w: f32 = 140;
/// Actions on each page of the Controls list. The compact page keeps the native panel within a small view.
const controls_page_size = 3;

/// The screens the panel shows. Each is its own list of widgets, built in the update step.
const Screen = enum { demo, controls, saves };

/// Colors of the debug geometry the game draws: the player's collision box and its center marker.
const player_box_color = engine.diagnostics.Color{ .r = 0.3, .g = 1.0, .b = 0.4, .a = 0.9 };
const player_marker_color = engine.diagnostics.Color{ .r = 1.0, .g = 0.85, .b = 0.2, .a = 1.0 };

/// One placed entity: the prefab it was made from, and the cell it stands on.
const Placed = struct {
    prefab: prefab.Id,
    col: u32,
    row: u32,
};

pub const Game = struct {
    level: Level,
    player: Player,
    /// One texture that holds every sprite. Packing them at build time means the whole world and
    /// the player sample the same texture, so they can share a draw call.
    atlas: engine.LoadedAtlas,
    /// Validated explicit frame data, owned for the duration of the game.
    animations: engine.animation.Library,
    /// The atlas regions of the sprites this game draws.
    tile: engine.atlas.Region,
    warrior: engine.atlas.Region,
    /// The entity templates from the prefab file. A placement names one of them by its index.
    prefabs: prefab.Registry,
    /// One entity for each placement the level metadata makes. Each row names the prefab it was made from.
    entities: engine.entity.World(Placed, .aos),
    /// The enemies the level places, each with its own brain and route. The list is freed in `deinit`.
    enemies: []enemy.Enemy,
    /// The warrior's clips, which enemies play. They point into `animations`, which lives as long as the game.
    enemy_clips: enemy.Clips,
    /// Plans the enemies' routes. Its arrays grow to the map's size on the first search, and are reused after that.
    pathfinder: engine.navigation.Pathfinder,
    /// The allocator the enemy list came from, so `deinit` can free it.
    allocator: std.mem.Allocator,
    /// Immediate-mode UI for the demo panel. It owns its font and its widget state.
    ui: engine.ui.Ui,
    /// Demo panel state: how often the button was clicked, and the slider value.
    clicks: u32,
    volume: f32,
    /// Which screen the panel shows, and which page of the Controls list. Neither is saved.
    screen: Screen = .demo,
    controls_page: usize = 0,
    /// True only while the in-game menu is open. F8 toggles it, keeping titles, buttons, sliders and
    /// other menu details out of normal gameplay.
    ui_visible: bool = false,
    /// The save slot that F5 and F9 use, and which slots hold a save. The slot is not saved, so the game starts on slot 1.
    save_slot: usize = 0,
    slot_used: [config.save_slot_files.len]bool = [_]bool{false} ** config.save_slot_files.len,
    /// True after the Clear button of the Saves page is pressed once. A second press erases the slot.
    clear_armed: bool = false,
    audio: *engine.audio.Audio,
    ambient_sound: ?engine.audio.Sound,
    ambient_voice: ?engine.audio.Handle,
    ambient_attempted: bool,
    /// Key bindings from the settings file, with the defaults for anything it leaves out.
    bindings: controls.Bindings,
    /// True when indexed assets, including the atlas image, are watched by the dependency graph.
    asset_graph_watched: bool,
    /// Held keys, for the debug lines and the actions. It lives as long as the session.
    input: *const engine.Input,
    /// The gameplay script, when one loaded. See attachScript. Null when the game runs without one.
    script: ?engine.script.Vm = null,
    /// The state the script's bindings read and write. It lives on the heap, because the bindings keep its address
    /// and Game is returned by value.
    script_bridge: ?*script_host.Bridge = null,

    pub fn init(ctx: *engine.Context) engine.AssetError!Game {
        const zone = engine.profile.zoneNamed(@src(), "game init");
        defer zone.End();
        var atlas = ctx.loadAtlas(config.atlas_image_path, config.atlas_index_path) catch |err| {
            log.err("required atlas '{s}'/ '{s}' failed to load: {s}", .{ config.atlas_image_path, config.atlas_index_path, @errorName(err) });
            return err;
        };
        errdefer atlas.deinit();
        const asset_graph_watched = watchAtlas(ctx);
        log.info("atlas {d}x{d} with {d} sprites", .{ atlas.texture.width, atlas.texture.height, atlas.index.len });

        const tile = atlas.region("tile");
        const warrior = atlas.region("warrior");
        var animations = loadAnimations(ctx, config.animation_path, warrior.w, warrior.h) catch |err| {
            log.err("required animation data '{s}' failed to load: {s}", .{ config.animation_path, @errorName(err) });
            return err;
        };
        errdefer animations.deinit();
        inline for (.{ "idle_down", "walk_down", "idle_up", "walk_up", "idle_left", "walk_left", "idle_right", "walk_right" }) |name| {
            if (animations.find(name) == null) {
                log.err("animation data '{s}' is missing required clip '{s}'", .{ config.animation_path, name });
                return error.InvalidAnimation;
            }
        }
        const enemy_clips = enemy.Clips.resolve(&animations) orelse {
            log.err("animation data '{s}' is missing a clip that enemies play", .{config.animation_path});
            return error.InvalidAnimation;
        };
        const registry = loadPrefabs(ctx, config.prefab_path) catch |err| {
            log.err("required prefab file '{s}' failed to load: {s}", .{ config.prefab_path, @errorName(err) });
            return err;
        };
        var level = Level.load(ctx, config.level_path, config.level_spawn_path, &registry) catch |err| {
            log.err("required level '{s}' or its metadata '{s}' failed to load: {s}", .{ config.level_path, config.level_spawn_path, @errorName(err) });
            return err;
        };
        errdefer level.deinit();
        checkTileset(&level, tile);
        if (!registry.tilesFit(tile.cellCount(engine.tilemap.tile_size))) {
            log.err("prefab file '{s}' draws a tile that the tileset '{s}' does not have", .{ config.prefab_path, config.atlas_image_path });
            return error.InvalidLevel;
        }

        const spawn = level.spawn;
        var machine_def = loadMachine(ctx, config.machine_path, &animations) catch |err| {
            log.err("required animation machine '{s}' failed to load: {s}", .{ config.machine_path, @errorName(err) });
            return err;
        };
        inline for (.{ "moving", "facing" }) |name| {
            if (machine_def.findParam(name) == null) {
                log.err("animation machine '{s}' is missing required parameter '{s}'", .{ config.machine_path, name });
                machine_def.deinit();
                return error.InvalidAnimation;
            }
        }
        var player = Player.standingOn(spawn.col, spawn.row, &animations, machine_def);
        errdefer player.deinit();
        log.info("map {d}x{d} tiles, player starts on tile ({d}, {d})", .{ level.map.cols, level.map.rows, spawn.col, spawn.row });

        var entities = engine.entity.World(Placed, .aos).init(ctx.allocators.game);
        errdefer entities.deinit();
        for (level.placements) |placement| {
            _ = entities.spawn(.{ .prefab = placement.prefab, .col = placement.col, .row = placement.row }) catch return error.OutOfMemory;
        }
        log.info("{d} placed entities spawned from the level metadata", .{entities.count()});

        const ui_font = ctx.loadFont(config.ui_font_path, config.ui_font_px) catch |err| {
            log.err("required UI font '{s}' failed to load: {s}", .{ config.ui_font_path, @errorName(err) });
            return err;
        };
        const ui = engine.ui.Ui.init(ctx.allocators.game, ui_font);
        const bindings = controls.load(ctx.settings_text);
        const ambient_sound: ?engine.audio.Sound = ctx.loadSound(config.ambient_sound_path) catch |err| blk: {
            if (err != error.NoDevice) log.warn("ambient sound could not be loaded: {s}", .{@errorName(err)});
            break :blk null;
        };

        // Nothing below can fail, so these need no cleanup on the error paths above.
        var pathfinder = engine.navigation.Pathfinder.init(ctx.allocators.game) catch return error.OutOfMemory;
        errdefer pathfinder.deinit();
        const enemies = spawnEnemies(ctx.allocators.game, level.enemies, &enemy_clips) catch return error.OutOfMemory;

        var game: Game = .{
            .level = level,
            .player = player,
            .atlas = atlas,
            .animations = animations,
            .tile = tile,
            .warrior = warrior,
            .prefabs = registry,
            .entities = entities,
            .ui = ui,
            .clicks = 0,
            .volume = 0.5,
            .ui_visible = false,
            .audio = ctx.audio,
            .ambient_sound = ambient_sound,
            .ambient_voice = null,
            .ambient_attempted = false,
            .bindings = bindings,
            .asset_graph_watched = asset_graph_watched,
            .input = ctx.input,
            .enemies = enemies,
            .enemy_clips = enemy_clips,
            .pathfinder = pathfinder,
            .allocator = ctx.allocators.game,
        };
        game.loadSave(ctx);
        game.refreshSlots(ctx);
        game.attachScript(ctx);
        return game;
    }

    /// Adds the game's lines to the diagnostics overlay: where the player is, which way it faces, and
    /// which movement keys are held. The engine calls this once per frame, in development builds only.
    pub fn debugText(self: *const Game, out: *engine.diagnostics.Text) void {
        out.print("player {d:.1}, {d:.1}  facing {s}", .{ self.player.transform.position[0], self.player.transform.position[1], @tagName(self.player.facing) });
        out.print("move held: L{d} R{d} U{d} D{d}  clicks {d}", .{
            @intFromBool(self.bindings.held(self.input, .move_left)),
            @intFromBool(self.bindings.held(self.input, .move_right)),
            @intFromBool(self.bindings.held(self.input, .move_up)),
            @intFromBool(self.bindings.held(self.input, .move_down)),
            self.clicks,
        });
        var chasing: usize = 0;
        for (self.enemies) |*each| {
            if (each.isChasing()) chasing += 1;
        }
        out.print("enemies {d}, chasing {d}", .{ self.enemies.len, chasing });
    }

    /// The actions held now, as the game's bindings resolve them from the held keys. The overlay lists them.
    pub fn debugActions(self: *const Game, input: *const engine.Input, out: *engine.diagnostics.NameList) void {
        self.bindings.addHeldNames(input, out);
    }

    pub fn deinit(self: *Game) void {
        if (self.script) |*vm| vm.deinit();
        if (self.ambient_voice) |voice| self.audio.stop(voice);
        if (self.ambient_sound) |*sound| sound.deinit();
        self.level.deinit();
        self.player.deinit();
        self.entities.deinit();
        self.allocator.free(self.enemies);
        self.pathfinder.deinit();
        self.animations.deinit();
        self.atlas.deinit();
        self.ui.deinit();
    }

    /// Runs at the fixed update rate. `ctx.dt` is the length of the step. `nav` asks for a change of
    /// scene. This game is one scene, so it never asks.
    pub fn update(self: *Game, ctx: *engine.Context, nav: *engine.SceneNavigator) void {
        _ = nav;
        self.reloadAtlasIfChanged(ctx);
        self.startAmbient();
        const input = ctx.input;
        if (input.wasPressed(.f8)) {
            self.ui_visible = !self.ui_visible;
            if (!self.ui_visible) self.ui.cancelListening();
            if (!self.ui_visible) self.ui.clear();
        }
        // While a keybind row waits, the key pressed picks the binding, so no action runs. Escape then only cancels the wait.
        const acting = !self.ui.listening();
        if (acting and self.bindings.pressed(input, .quit)) {
            log.info("quit action pressed", .{});
            ctx.running = false;
        }
        if (acting and self.bindings.pressed(input, .save_game)) self.saveGame(ctx);
        if (acting and self.bindings.pressed(input, .load_game)) self.loadSave(ctx);
        if (acting and self.bindings.pressed(input, .cycle_save_slot)) {
            self.chooseSlot(save_store.nextSlot(self.save_slot, config.save_slot_files.len));
        }
        if (acting and self.bindings.pressed(input, .toggle_scale)) {
            ctx.scale_mode = switch (ctx.scale_mode) {
                .integer => .fit,
                .fit => .integer,
            };
        }
        if (acting and self.bindings.pressed(input, .zoom_in)) ctx.zoomBy(config.zoom_step);
        if (acting and self.bindings.pressed(input, .zoom_out)) ctx.zoomBy(1.0 / config.zoom_step);
        if (acting and self.bindings.pressed(input, .zoom_reset)) ctx.resetZoom();
        if (ctx.diagnostics_enabled) {
            const world = &ctx.diagnostics.snapshot.world;
            world.collision_queries += 1;
            world.map_cols = self.level.map.cols;
            world.map_rows = self.level.map.rows;
            const cursor = ctx.mouseWorld();
            world.selected_col = @intFromFloat(@floor(cursor.x / engine.tilemap.tile_px));
            world.selected_row = @intFromFloat(@floor(cursor.y / engine.tilemap.tile_px));
            world.selected_tile = self.level.map.idAt(.ground, world.selected_col, world.selected_row);
            world.selected_solid = self.level.map.isSolid(world.selected_col, world.selected_row);
        }

        // Each movement action contributes one unit on its axis.
        var dx: f32 = 0;
        var dy: f32 = 0;
        if (acting) {
            if (self.bindings.held(input, .move_left)) dx -= 1;
            if (self.bindings.held(input, .move_right)) dx += 1;
            if (self.bindings.held(input, .move_up)) dy -= 1;
            if (self.bindings.held(input, .move_down)) dy += 1;
        }

        self.player.update(dx, dy, ctx.dt, &self.level.map, &self.animations);
        self.updateEnemies(ctx.dt);
        if (ctx.diagnostics_enabled) self.publishEntitySnapshot(ctx);
        if (self.ui_visible) self.updateUi(ctx);
        self.runScript(ctx);
    }

    /// Loads the gameplay script and binds the game's functions to it. A missing or broken script is logged, and the
    /// game runs without one. Nothing here can stop the game from starting.
    fn attachScript(self: *Game, ctx: *engine.Context) void {
        const bridge = ctx.allocators.game.create(script_host.Bridge) catch {
            log.err("could not allocate the script bridge, so the game runs without scripts", .{});
            return;
        };
        bridge.* = .{ .ctx = ctx };
        var vm = engine.script.Vm.init(config.script_max_steps) catch {
            log.err("could not create the script runtime, so the game runs without scripts", .{});
            return;
        };
        script_host.bind(&vm, bridge) catch |err| {
            log.err("script bindings failed ({s}), so the game runs without scripts", .{@errorName(err)});
            vm.deinit();
            return;
        };
        const source = ctx.readFile(ctx.allocators.asset, config.script_path) catch |err| {
            log.warn("script '{s}' could not be read ({s}), so the game runs without one", .{ config.script_path, @errorName(err) });
            vm.deinit();
            return;
        };
        defer ctx.allocators.asset.free(source);
        vm.load(config.script_path, source) catch {
            log.err("script '{s}' failed to load: {s}", .{ config.script_path, vm.errorText() });
            vm.deinit();
            return;
        };
        self.script = vm;
        self.script_bridge = bridge;
        log.info("script '{s}' loaded", .{config.script_path});
    }

    /// Calls the script's `on_update` hook once per update step. The game's values go in first, and the volume the
    /// script set comes back out. A script that fails is reported once and turned off, so a broken script can't flood
    /// the log every step.
    fn runScript(self: *Game, ctx: *engine.Context) void {
        const bridge = self.script_bridge orelse return;
        if (self.script) |*vm| {
            bridge.* = .{ .ctx = ctx, .clicks = self.clicks, .volume = self.volume, .dt = ctx.dt };
            if (vm.call("on_update", &.{})) |_| {} else |_| {
                log.err("script stopped after an error: {s}", .{vm.errorText()});
                vm.deinit();
                self.script = null;
            }
            self.volume = bridge.volume;
        }
    }

    fn publishEntitySnapshot(self: *const Game, ctx: *engine.Context) void {
        var values: [4][engine.diagnostics.component_value_capacity]u8 = undefined;
        const transform = std.fmt.bufPrint(&values[0], "x={d:.2} y={d:.2} z={d:.2}", .{
            self.player.transform.position[0],
            self.player.transform.position[1],
            self.player.transform.position[2],
        }) catch |err| {
            log.warn("entity diagnostics transform was not formatted: {s}", .{@errorName(err)});
            return;
        };
        const facing = std.fmt.bufPrint(&values[1], "{s}", .{@tagName(self.player.facing)}) catch |err| {
            log.warn("entity diagnostics facing was not formatted: {s}", .{@errorName(err)});
            return;
        };
        const animation = std.fmt.bufPrint(&values[2], "{s}/{s} frame={d} time={d:.2}", .{
            self.player.machine.stateName(),
            self.player.machine.clipName(),
            self.player.machine.frameIndex(),
            self.player.machine.clipTime(),
        }) catch |err| {
            log.warn("entity diagnostics animation was not formatted: {s}", .{@errorName(err)});
            return;
        };
        const collider = Player.feetAt(self.player.transform.position[0], self.player.transform.position[1]);
        const collision_box = std.fmt.bufPrint(&values[3], "x={d:.1} y={d:.1} w={d:.1} h={d:.1}", .{
            collider.x,
            collider.y,
            collider.w,
            collider.h,
        }) catch |err| {
            log.warn("entity diagnostics collider was not formatted: {s}", .{@errorName(err)});
            return;
        };
        const components = [_]engine.diagnostics.ComponentInput{
            .{ .name = "transform", .value = transform },
            .{ .name = "facing", .value = facing },
            .{ .name = "animation", .value = animation },
            .{ .name = "collider", .value = collision_box },
        };
        const entities = [_]engine.diagnostics.EntityInput{.{
            .id = 1,
            .name = "player",
            .components = &components,
        }};
        ctx.diagnostics.publishEntities(1, &entities) catch |err| {
            log.warn("entity diagnostics snapshot was not published: {s}", .{@errorName(err)});
        };
    }

    /// Registers the atlas files for hot reload. In a release build this watches nothing. A file that cannot
    /// be watched only means that its changes are not picked up, so it is logged and startup goes on.
    fn watchAtlas(ctx: *engine.Context) bool {
        var graph_watched = true;
        ctx.watchAssetGraph(config.asset_index_path) catch |err| {
            graph_watched = false;
            log.warn("asset dependency index '{s}' is not watched for reload: {s}", .{ config.asset_index_path, @errorName(err) });
        };
        if (!graph_watched) {
            ctx.watchAsset(config.atlas_image_path, .atlas) catch |err| log.warn("'{s}' is not watched for reload: {s}", .{ config.atlas_image_path, @errorName(err) });
        }
        ctx.watchAsset(config.atlas_index_path, .atlas) catch |err| log.warn("'{s}' is not watched for reload: {s}", .{ config.atlas_index_path, @errorName(err) });
        return graph_watched;
    }

    /// Reloads the atlas when its image or index changed on disk. The replacement is loaded and checked first,
    /// and the game switches to it only when it is valid. The GPU must finish with the old atlas before it is
    /// released, so the old one goes last. A rejected reload keeps the atlas the game already has, and logs why.
    fn reloadAtlasIfChanged(self: *Game, ctx: *engine.Context) void {
        const index_changed = ctx.takeChanged(config.atlas_index_path);
        const image_changed = if (self.asset_graph_watched)
            ctx.takeAssetChanged("atlas")
        else
            ctx.takeChanged(config.atlas_image_path);
        if (!index_changed and !image_changed) return;

        var fresh = ctx.loadAtlas(config.atlas_image_path, config.atlas_index_path) catch |err| {
            log.warn("atlas reload rejected, keeping the current atlas: {s}", .{@errorName(err)});
            return;
        };
        const tile = fresh.index.find("tile") orelse {
            fresh.deinit();
            log.warn("atlas reload rejected: sprite 'tile' is missing; keeping the current atlas", .{});
            return;
        };
        const warrior = fresh.index.find("warrior") orelse {
            fresh.deinit();
            log.warn("atlas reload rejected: sprite 'warrior' is missing; keeping the current atlas", .{});
            return;
        };
        if (!tilesetFits(&self.level, tile)) {
            fresh.deinit();
            log.warn("atlas reload rejected: the level uses tiles the new tile sprite lacks; keeping the current atlas", .{});
            return;
        }
        if (!self.prefabs.tilesFit(tile.cellCount(engine.tilemap.tile_size))) {
            fresh.deinit();
            log.warn("atlas reload rejected: a prefab draws a tile the new tileset lacks; keeping the current atlas", .{});
            return;
        }

        ctx.waitGpuIdle();
        self.atlas.deinit();
        self.atlas = fresh;
        self.tile = tile;
        self.warrior = warrior;
        log.info("atlas reloaded: {d}x{d} with {d} sprites", .{ self.atlas.texture.width, self.atlas.texture.height, self.atlas.index.len });
    }

    fn startAmbient(self: *Game) void {
        if (self.ambient_attempted) return;
        self.ambient_attempted = true;
        if (self.ambient_sound) |*sound| {
            self.ambient_voice = self.audio.play(sound, .{ .loop = true }) catch |err| {
                log.warn("ambient sound could not start: {s}", .{@errorName(err)});
                return;
            };
        }
    }

    fn saveGame(self: *Game, ctx: *const engine.Context) void {
        const state = save_store.State{
            .player_transform = .{
                .position = self.player.transform.position,
                .rotation = self.player.transform.rotation,
                .scale = self.player.transform.scale,
            },
            .facing = self.player.facing,
            .moving = self.player.moving,
            .animation_time = self.player.machine.clipTime(),
            .clicks = self.clicks,
            .volume = self.volume,
            .scale_mode = if (ctx.scale_mode == .integer) .integer else .fit,
            .zoom_target = ctx.zoom_target,
        };
        const json = save_store.serialize(ctx.allocators.frame, state) catch |err| {
            log.err("save serialization failed: {s}", .{@errorName(err)});
            return;
        };
        defer ctx.allocators.frame.free(json);

        const file = config.save_slot_files[self.save_slot];
        // writeFile logs the reason when the write fails, so there is nothing more to say here.
        ctx.writeFile(file, json) catch |err| {
            log.err("save '{s}' was not written: {s}", .{ file, @errorName(err) });
            return;
        };
        self.slot_used[self.save_slot] = true;
        log.info("saved game to {s}", .{file});
    }

    fn loadSave(self: *Game, ctx: *engine.Context) void {
        const file = config.save_slot_files[self.save_slot];
        const text = ctx.readFile(ctx.allocators.frame, file) catch |err| {
            if (err != error.FileNotFound) log.warn("save '{s}' could not be read: {s}", .{ file, @errorName(err) });
            return;
        };
        defer ctx.allocators.frame.free(text);

        const defaults = save_store.State{
            .player_transform = .{
                .position = self.player.transform.position,
                .rotation = self.player.transform.rotation,
                .scale = self.player.transform.scale,
            },
            .facing = self.player.facing,
            .clicks = self.clicks,
            .volume = self.volume,
            .scale_mode = if (ctx.scale_mode == .integer) .integer else .fit,
            .zoom_target = ctx.zoom_target,
        };
        const state = save_store.deserialize(ctx.allocators.frame, text, defaults) catch |err| {
            log.warn("save '{s}' was ignored: {s}", .{ file, @errorName(err) });
            return;
        };
        if (!state.level_matches) {
            log.warn("save '{s}' belongs to a different level; it was ignored", .{file});
            return;
        }

        if (positionIsValid(state.player_transform.position[0], state.player_transform.position[1], &self.level)) {
            self.player.restore(.{
                .position = state.player_transform.position,
                .rotation = state.player_transform.rotation,
                .scale = state.player_transform.scale,
            }, state.facing, state.moving, state.animation_time, &self.animations);
        } else {
            log.warn("saved player position is outside the current level; using the level spawn", .{});
        }
        self.clicks = state.clicks;
        self.volume = state.volume;
        ctx.scale_mode = if (state.scale_mode == .integer) .integer else .fit;
        ctx.zoom_target = std.math.clamp(state.zoom_target, config.zoom_min, config.zoom_max);
        log.info("loaded game from {s}", .{file});
    }

    /// Runs once per frame. `dc.alpha` blends the player between the last two updates. The camera
    /// eases toward the player using the frame time, so its speed doesn't depend on the frame rate.
    pub fn draw(self: *Game, dc: *const engine.DrawContext) void {
        const center = self.player.drawCenter(dc.alpha);
        dc.cam.world_w = self.level.widthPx();
        dc.cam.world_h = self.level.heightPx();
        dc.cam.followSmooth(center.x, center.y, dc.dt, config.camera_rate);

        // Draw order: ground, decoration, placed entities, the player, and then foreground, which can cover the player.
        const tiles = &self.atlas.texture;
        const map = &self.level.map;
        if (dc.layers.ground) engine.tilemap_draw.drawLayer(map, dc.batch, tiles, self.tile, dc.cam, .ground, .{});
        if (dc.layers.decoration) engine.tilemap_draw.drawLayer(map, dc.batch, tiles, self.tile, dc.cam, .decoration, .{});
        self.drawPlaced(dc.batch, tiles, dc.cam);
        self.drawEnemies(dc.batch, tiles, dc.cam, dc.alpha);
        self.player.draw(dc.batch, tiles, self.warrior, dc.cam, dc.alpha);
        if (dc.layers.foreground) engine.tilemap_draw.drawLayer(map, dc.batch, tiles, self.tile, dc.cam, .foreground, .{});

        // Debug geometry is queued as shapes, and only while its switch is on, so an idle build does no work.
        if (dc.show.tiles) engine.debug_geometry.drawGrid(map, dc.debug, dc.cam);
        if (dc.show.collision) {
            engine.debug_geometry.drawSolid(map, dc.debug, dc.cam);
            const feet = self.player.collisionBox(dc.alpha);
            dc.debug.outline(dc.cam.screenX(feet.x), dc.cam.screenY(feet.y), feet.w, feet.h, player_box_color);
        }
        if (dc.show.entities) {
            for (self.enemies) |*each| each.drawDebug(dc.debug, dc.cam);
            const player_center = self.player.drawCenter(dc.alpha);
            dc.debug.point(dc.cam.screenX(player_center.x), dc.cam.screenY(player_center.y), player_marker_color);
        }

        // The panel goes last. Its quads were built in the update step, so this only queues them.
        self.ui.queue(dc.batch, ui_z);
    }

    /// Runs every enemy for one update step. The enemies aim at the center of the player's feet, which is where the
    /// player's collision box is, so the sight line and the route end on the cell the player stands in.
    fn updateEnemies(self: *Game, dt: f32) void {
        const feet = self.player.collisionBox(1);
        const center = engine.tilemap.Point{ .x = feet.x + feet.w / 2.0, .y = feet.y + feet.h / 2.0 };
        const stage = enemy.Stage{
            .map = &self.level.map,
            .finder = &self.pathfinder,
            .target = .{ .center = center, .cell = engine.navigation.cellOf(center) },
            .clips = &self.enemy_clips,
            .dt = dt,
        };
        for (self.enemies) |*each| each.update(stage);
    }

    /// Queues every enemy's frame. They are drawn before the player, so the player stands in front of them.
    fn drawEnemies(self: *const Game, batch: *engine.SpriteBatch, texture: *const engine.Texture, cam: *const engine.Camera, alpha: f32) void {
        for (self.enemies) |*each| each.draw(batch, texture, self.warrior, cam, alpha);
    }

    /// Queues one sprite for each placed entity. The sprite is the tile its prefab names, read from the tileset the same
    /// way the tile layers read it, and it sits on the cell the entity stands on.
    fn drawPlaced(self: *const Game, batch: *engine.SpriteBatch, texture: *const engine.Texture, cam: *const engine.Camera) void {
        const tile_px = engine.tilemap.tile_px;
        const tile_size = engine.tilemap.tile_size;
        const across = self.tile.cellsAcross(tile_size);
        var row: usize = 0;
        while (row < self.entities.count()) : (row += 1) {
            const placed = self.entities.get(self.entities.handleAt(row)).?;
            const id = self.prefabs.get(placed.prefab).tile;
            const src = engine.Rect{
                .x = @floatFromInt(self.tile.x + (id % across) * tile_size),
                .y = @floatFromInt(self.tile.y + (id / across) * tile_size),
                .w = tile_px,
                .h = tile_px,
            };
            const dst = engine.Rect{
                .x = cam.screenX(@as(f32, @floatFromInt(placed.col)) * tile_px),
                .y = cam.screenY(@as(f32, @floatFromInt(placed.row)) * tile_px),
                .w = tile_px,
                .h = tile_px,
            };
            batch.drawSprite(texture, src, dst, .{});
        }
    }

    /// Builds the panel for this frame. It runs in the update step, so each press and release reaches the widgets
    /// exactly once. The panel shows the demo, or the Controls list when it is open.
    fn updateUi(self: *Game, ctx: *engine.Context) void {
        const ui = &self.ui;
        // Anchor and pointer mapping use the same current layout as presentation, including
        // window resizes, high-DPI density, integer-mode letterboxing, and zoom.
        const panel_width = @min(panel_w, @max(112.0, ctx.layout.view_w * 0.44));
        const desired_panel_height: f32 = switch (self.screen) {
            .demo => 96,
            .controls => 84,
            .saves => 84,
        };
        const panel_height = @min(desired_panel_height, @max(1, ctx.layout.view_h - 8));
        const snapped_panel_width = if (ctx.layout.pixel_perfect) @round(panel_width) else panel_width;
        const snapped_panel_height = if (ctx.layout.pixel_perfect) @round(panel_height) else panel_height;
        const panel = engine.ui.anchorBounds(ctx.layout.view_w, ctx.layout.view_h, snapped_panel_width, snapped_panel_height, .top_left, 4, 4);
        ui.begin(ctx.input, ctx.layout, panel.x, panel.y, panel.w);
        switch (self.screen) {
            .demo => self.updateDemo(),
            .controls => self.updateControls(ctx),
            .saves => self.updateSaves(ctx),
        }
        self.audio.setMasterGain(self.volume);
        ui.end();
    }

    /// The demo rows: a label, the click counter, and the volume slider. The last row opens the Controls list.
    fn updateDemo(self: *Game) void {
        const ui = &self.ui;
        ui.label("Semkootru");
        var slot_buf: [48]u8 = undefined;
        const status: []const u8 = if (self.slot_used[self.save_slot]) "saved" else "empty";
        ui.label(std.fmt.bufPrint(&slot_buf, "Slot {d}: {s}  F5/F9", .{ self.save_slot + 1, status }) catch
            std.debug.panic("slot label does not fit its buffer", .{}));
        if (ui.button("Click me##go")) self.clicks += 1;

        var clicks_buf: [32]u8 = undefined;
        ui.label(std.fmt.bufPrint(&clicks_buf, "Clicks: {d}", .{self.clicks}) catch
            std.debug.panic("click label does not fit its buffer", .{}));
        _ = ui.slider("Volume", &self.volume, 0, 1);
        var level_buf: [32]u8 = undefined;
        ui.label(std.fmt.bufPrint(&level_buf, "Level: {d:.2}", .{self.volume}) catch
            std.debug.panic("level label does not fit its buffer", .{}));
        if (ui.button("Saves")) self.screen = .saves;
        if (ui.button("Controls")) self.screen = .controls;
    }

    /// The Controls list: a keybind row for each action on the current page, then Next and Back. Picking a row
    /// rebinds its action to the binding pressed next, which replaces the action's earlier bindings.
    fn updateControls(self: *Game, ctx: *engine.Context) void {
        const ui = &self.ui;
        const actions = std.enums.values(controls.Action);
        const pages = (actions.len + controls_page_size - 1) / controls_page_size;
        if (self.controls_page >= pages) self.controls_page = 0;

        var title_buf: [32]u8 = undefined;
        ui.label(std.fmt.bufPrint(&title_buf, "Controls {d}/{d}", .{ self.controls_page + 1, pages }) catch
            std.debug.panic("controls title does not fit its buffer", .{}));
        const first = self.controls_page * controls_page_size;
        const last = @min(first + controls_page_size, actions.len);
        for (actions[first..last]) |which| {
            var value_buf: [engine.bindings.binding_text_capacity]u8 = undefined;
            const current = engine.bindings.bindingsText(&value_buf, self.bindings.bindingsOf(which));
            if (ui.keybind(@tagName(which), current)) |binding| {
                controls.rebind(ctx, &self.bindings, which, &.{binding}) catch |err| {
                    log.warn("binding for {s} was not saved: {s}", .{ @tagName(which), @errorName(err) });
                };
            }
        }
        if (ui.button("Next")) self.controls_page = (self.controls_page + 1) % pages;
        if (ui.button("Back")) self.screen = .demo;
    }

    /// The Saves page: a row for each slot that selects it, then Clear, which erases the selected slot after a
    /// second press, and Back. A row shows whether its slot holds a save.
    fn updateSaves(self: *Game, ctx: *const engine.Context) void {
        const ui = &self.ui;
        ui.label("Saves");
        for (config.save_slot_files, 0..) |_, slot| {
            var row_buf: [48]u8 = undefined;
            const marker: []const u8 = if (slot == self.save_slot) "> " else "  ";
            const status: []const u8 = if (self.slot_used[slot]) "saved" else "empty";
            const text = std.fmt.bufPrint(&row_buf, "{s}Slot {d}: {s}", .{ marker, slot + 1, status }) catch
                std.debug.panic("save slot row does not fit its buffer", .{});
            if (ui.button(text)) self.chooseSlot(slot);
        }
        if (ui.button("Clear slot##clear")) {
            if (self.clear_armed) {
                self.clearSlot(ctx);
            } else {
                self.clear_armed = true;
            }
        }
        const note: []const u8 = if (self.clear_armed) "Clear again to erase" else "";
        ui.label(note);
        if (ui.button("Back##back")) {
            self.clear_armed = false;
            self.screen = .demo;
        }
    }

    /// Makes `slot` the one F5 and F9 use. Picking another slot disarms a pending clear.
    fn chooseSlot(self: *Game, slot: usize) void {
        self.save_slot = slot;
        self.clear_armed = false;
    }

    /// Records which slots hold a save. Startup calls this. Writing and clearing a slot update its entry directly,
    /// so the panel never reads files while it draws.
    fn refreshSlots(self: *Game, ctx: *const engine.Context) void {
        for (config.save_slot_files, 0..) |file, slot| {
            self.slot_used[slot] = ctx.fileExistsBeside(file);
        }
    }

    /// Erases the selected slot's save file. A slot with no file is already clear, so that is not an error.
    fn clearSlot(self: *Game, ctx: *const engine.Context) void {
        const file = config.save_slot_files[self.save_slot];
        ctx.removeFile(file) catch |err| {
            if (err != error.FileNotFound) {
                log.err("save slot {d} was not cleared: {s}", .{ self.save_slot + 1, @errorName(err) });
                return;
            }
        };
        self.slot_used[self.save_slot] = false;
        self.clear_armed = false;
        log.info("cleared save slot {d}", .{self.save_slot + 1});
    }
};

/// One enemy for each home cell the level names. Each enemy gets its own brain seed, so the enemies wander differently.
fn spawnEnemies(allocator: std.mem.Allocator, homes: []const level_data.Spawn, clips: *const enemy.Clips) std.mem.Allocator.Error![]enemy.Enemy {
    const enemies = try allocator.alloc(enemy.Enemy, homes.len);
    for (homes, 0..) |home, index| {
        const seed: u32 = @as(u32, @intCast(index + 1)) *% 2654435761;
        const cell = engine.navigation.Cell{ .col = @intCast(home.col), .row = @intCast(home.row) };
        enemies[index] = enemy.Enemy.spawn(cell, seed, clips);
    }
    return enemies;
}

/// Reads and parses the prefab file. A file that cannot be read or parsed stops startup, the same as a bad map.
fn loadPrefabs(ctx: *const engine.Context, path: []const u8) engine.AssetError!prefab.Registry {
    const source = ctx.readFile(ctx.allocators.asset, path) catch |err| {
        return switch (err) {
            error.FileNotFound => error.FileNotFound,
            error.PathTooLong => error.PathTooLong,
            error.OutOfMemory => error.OutOfMemory,
            else => error.ReadFailed,
        };
    };
    defer ctx.allocators.asset.free(source);
    return prefab.parse(source) catch |err| {
        log.err("prefab file '{s}' is not valid: {s}", .{ path, @errorName(err) });
        return error.InvalidLevel;
    };
}

/// Reads the animation machine's text and checks it against the clips in `animations`.
fn loadMachine(ctx: *const engine.Context, path: []const u8, animations: *const engine.animation.Library) engine.AssetError!engine.animation.MachineDefinition {
    const source = ctx.readFile(ctx.allocators.asset, path) catch |err| {
        return switch (err) {
            error.FileNotFound => error.FileNotFound,
            error.PathTooLong => error.PathTooLong,
            error.OutOfMemory => error.OutOfMemory,
            else => error.ReadFailed,
        };
    };
    defer ctx.allocators.asset.free(source);
    return engine.animation.MachineDefinition.parse(ctx.allocators.asset, source, animations) catch |err| {
        return switch (err) {
            error.OutOfMemory => error.OutOfMemory,
            else => error.InvalidAnimation,
        };
    };
}

fn loadAnimations(ctx: *const engine.Context, path: []const u8, width_px: u32, height_px: u32) engine.AssetError!engine.animation.Library {
    const source = ctx.readFile(ctx.allocators.asset, path) catch |err| {
        return switch (err) {
            error.FileNotFound => error.FileNotFound,
            error.PathTooLong => error.PathTooLong,
            error.OutOfMemory => error.OutOfMemory,
            else => error.ReadFailed,
        };
    };
    defer ctx.allocators.asset.free(source);
    return engine.animation.Library.parse(ctx.allocators.asset, source, width_px, height_px) catch |err| {
        return switch (err) {
            error.OutOfMemory => error.OutOfMemory,
            else => error.InvalidAnimation,
        };
    };
}

/// True when every tile ID in the level names a tile in the tileset. A reload uses this to refuse an atlas that
/// would draw blank or wrong tiles, without stopping the game the way the startup check does.
fn tilesetFits(level: *const Level, tileset: engine.atlas.Region) bool {
    const count = tileset.cellCount(engine.tilemap.tile_size);
    if (level.map.tileset_count) |expected| {
        if (expected != count) return false;
    }
    return level.map.largestId() < count;
}

/// True when a player whose top-left corner is at (x, y) fits in the level without touching a solid
/// tile. The bounds check uses the whole sprite, and the collision check uses the feet.
fn positionIsValid(x: f32, y: f32, level: *const Level) bool {
    if (!std.math.isFinite(x) or !std.math.isFinite(y) or x < 0 or y < 0 or
        x + Player.sprite_w > level.widthPx() or y + Player.sprite_h > level.heightPx()) return false;
    return !level.map.boxOverlapsSolid(Player.feetAt(x, y));
}

/// Every tile ID in the map must name a tile in the tile sprite. Otherwise the map would draw blank
/// or wrong tiles. Panics with the offending ID so the map or the sprite can be fixed.
fn checkTileset(level: *const Level, tileset: engine.atlas.Region) void {
    const count = tileset.cellCount(engine.tilemap.tile_size);
    if (level.map.tileset_count) |expected| {
        if (expected != count) {
            std.debug.panic("the map expects {d} tiles, but the tile sprite holds {d}", .{ expected, count });
        }
    }
    const largest = level.map.largestId();
    if (largest >= count) {
        std.debug.panic("the map uses tile ID {d}, but the tile sprite holds only {d} tiles", .{ largest, count });
    }
}
