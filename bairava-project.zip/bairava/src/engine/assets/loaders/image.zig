const std = @import("std");
const builtin = @import("builtin");

// Declarations only. The implementation is compiled from vendor/stb_image_impl.c.
const stb = @cImport({
    if (builtin.os.tag == .windows) {
        @cUndef("_FORTIFY_SOURCE");
        @cDefine("_FORTIFY_SOURCE", "0");
    }
    @cInclude("stb_image.h");
});

/// A decoded image in RGBA8 format, 4 bytes per pixel, row 0 at the top.
pub const Image = struct {
    width: u32,
    height: u32,
    pixels: []u8,

    pub fn deinit(self: *Image) void {
        stb.stbi_image_free(@ptrCast(self.pixels.ptr));
    }
};

pub const Compression = enum(u8) { rgba8 = 0, bc1 = 1, bc3 = 2, astc_4x4 = 3 };

/// A block-compressed texture read from the asset builder's BRTX container.
pub const CompressedImage = struct {
    allocator: std.mem.Allocator,
    width: u32,
    height: u32,
    format: Compression,
    blocks: []u8,

    pub fn deinit(self: *CompressedImage) void {
        self.allocator.free(self.blocks);
    }
};

/// Validates a BRTX variant and copies its payload. Kept separate from file I/O so format and
/// length validation can be tested without opening SDL or a GPU device.
pub fn parseCompressed(allocator: std.mem.Allocator, data: []const u8, expected: Compression) !CompressedImage {
    if (data.len < 16) return error.InvalidCompressedImage;
    if (!std.mem.eql(u8, data[0..4], "BRTX") or data[4] != @intFromEnum(expected)) return error.InvalidCompressedImage;
    const width = @as(u32, data[8]) | (@as(u32, data[9]) << 8) | (@as(u32, data[10]) << 16) | (@as(u32, data[11]) << 24);
    const height = @as(u32, data[12]) | (@as(u32, data[13]) << 8) | (@as(u32, data[14]) << 16) | (@as(u32, data[15]) << 24);
    if (width == 0 or height == 0) return error.InvalidCompressedImage;
    const expected_size: usize = if (expected == .rgba8) blk: {
        const pixels = std.math.mul(usize, width, height) catch return error.InvalidCompressedImage;
        break :blk std.math.mul(usize, pixels, 4) catch return error.InvalidCompressedImage;
    } else blk: {
        const bytes_per_block: usize = if (expected == .bc1) 8 else 16;
        const blocks_x = (@as(usize, width) + 3) / 4;
        const blocks_y = (@as(usize, height) + 3) / 4;
        const blocks = std.math.mul(usize, blocks_x, blocks_y) catch return error.InvalidCompressedImage;
        break :blk std.math.mul(usize, blocks, bytes_per_block) catch return error.InvalidCompressedImage;
    };
    if (data.len - 16 != expected_size) return error.InvalidCompressedImage;
    const blocks = try allocator.dupe(u8, data[16..]);
    return .{ .allocator = allocator, .width = width, .height = height, .format = expected, .blocks = blocks };
}

test "compressed variants validate dimensions and format-specific payload lengths" {
    const fixtures = @import("../../test_fixtures.zig");
    const cases = .{
        .{ .format = Compression.rgba8, .width = 2, .height = 2, .size = 16 },
        .{ .format = Compression.bc1, .width = 4, .height = 4, .size = 8 },
        .{ .format = Compression.bc3, .width = 4, .height = 4, .size = 16 },
        .{ .format = Compression.astc_4x4, .width = 4, .height = 4, .size = 16 },
    };
    inline for (cases) |case| {
        const bytes = try fixtures.compressedImageVariant(std.testing.allocator, @intFromEnum(case.format), case.width, case.height, case.size);
        defer std.testing.allocator.free(bytes);
        var parsed = try parseCompressed(std.testing.allocator, bytes, case.format);
        defer parsed.deinit();
        try std.testing.expectEqual(case.width, parsed.width);
        try std.testing.expectEqual(case.height, parsed.height);
        try std.testing.expectEqual(case.format, parsed.format);
        try std.testing.expectEqual(case.size, parsed.blocks.len);
    }
}

test "compressed variants reject truncated headers, mismatched formats, and invalid payload sizes" {
    const fixtures = @import("../../test_fixtures.zig");
    const valid = try fixtures.compressedImageVariant(std.testing.allocator, @intFromEnum(Compression.bc1), 4, 4, 8);
    defer std.testing.allocator.free(valid);
    try std.testing.expectError(error.InvalidCompressedImage, parseCompressed(std.testing.allocator, valid[0..15], .bc1));
    try std.testing.expectError(error.InvalidCompressedImage, parseCompressed(std.testing.allocator, valid, .bc3));
    try std.testing.expectError(error.InvalidCompressedImage, parseCompressed(std.testing.allocator, valid[0 .. valid.len - 1], .bc1));

    var bad_magic = try std.testing.allocator.dupe(u8, valid);
    defer std.testing.allocator.free(bad_magic);
    bad_magic[0] = 'X';
    try std.testing.expectError(error.InvalidCompressedImage, parseCompressed(std.testing.allocator, bad_magic, .bc1));
}

test "compressed variants reject zero dimensions and guard payload size overflow" {
    const fixtures = @import("../../test_fixtures.zig");
    const zero_width = try fixtures.compressedImageVariant(std.testing.allocator, @intFromEnum(Compression.rgba8), 0, 2, 0);
    defer std.testing.allocator.free(zero_width);
    try std.testing.expectError(error.InvalidCompressedImage, parseCompressed(std.testing.allocator, zero_width, .rgba8));

    const huge = try fixtures.compressedImageVariant(std.testing.allocator, @intFromEnum(Compression.rgba8), std.math.maxInt(u32), std.math.maxInt(u32), 0);
    defer std.testing.allocator.free(huge);
    try std.testing.expectError(error.InvalidCompressedImage, parseCompressed(std.testing.allocator, huge, .rgba8));
}

/// Decodes PNG (or any format supported by stb_image) bytes into RGBA8 pixels.
pub fn decodeRgba8(bytes: []const u8) !Image {
    if (bytes.len == 0 or bytes.len > std.math.maxInt(c_int)) return error.DecodeFailed;

    var width: c_int = 0;
    var height: c_int = 0;
    var channels: c_int = 0;
    const data = stb.stbi_load_from_memory(bytes.ptr, @intCast(bytes.len), &width, &height, &channels, 4);
    if (data == null) return error.DecodeFailed;

    const len = @as(usize, @intCast(width)) * @as(usize, @intCast(height)) * 4;
    const ptr: [*]u8 = @ptrCast(data);
    return .{
        .width = @intCast(width),
        .height = @intCast(height),
        .pixels = ptr[0..len],
    };
}

/// Returns the decoded RGBA8 allocation size without allocating the pixel buffer.
pub fn decodedRgba8Size(bytes: []const u8) !usize {
    if (bytes.len == 0 or bytes.len > std.math.maxInt(c_int)) return error.DecodeFailed;
    var width: c_int = 0;
    var height: c_int = 0;
    var channels: c_int = 0;
    if (stb.stbi_info_from_memory(bytes.ptr, @intCast(bytes.len), &width, &height, &channels) == 0 or width <= 0 or height <= 0) {
        return error.DecodeFailed;
    }
    const pixels = std.math.mul(usize, @intCast(width), @intCast(height)) catch return error.ImageTooLarge;
    return std.math.mul(usize, pixels, 4) catch return error.ImageTooLarge;
}
