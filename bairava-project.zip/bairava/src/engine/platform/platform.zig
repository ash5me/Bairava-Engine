//! The platform layer: everything that talks to the operating system or to SDL. Only the files
//! under platform/sdl/ import SDL, and the rest of the engine reaches the platform through here.

const std = @import("std");

const types = @import("types.zig");
const sdl_audio = @import("sdl/audio.zig");
const sdl_clock = @import("sdl/clock.zig");
const sdl_files = @import("sdl/files.zig");
const sdl_gpu = @import("sdl/gpu.zig");
const sdl_renderer2d = @import("sdl/renderer2d.zig");
const sdl_init = @import("sdl/init.zig");
const sdl_input = @import("sdl/input.zig");
const window_backend = @import("sdl/window.zig");

pub const Scancode = types.Scancode;
pub const MouseButton = types.MouseButton;
pub const Event = types.Event;
pub const Window = types.Window;
pub const PixelSize = types.PixelSize;
pub const Location = types.Location;
pub const FileError = types.FileError;
pub const max_full_path = types.max_full_path;
pub const AudioDevice = types.AudioDevice;
pub const AudioStream = types.AudioStream;
pub const OpenFile = types.OpenFile;
pub const PcmFormat = types.PcmFormat;
pub const PcmBuffer = types.PcmBuffer;
pub const OpenedAudio = types.OpenedAudio;
pub const AudioError = types.AudioError;
pub const Renderer2dTexture = opaque {};

/// Starts the platform: the video subsystem, which the window and GPU need, and the audio subsystem.
/// A video failure panics. An audio failure is logged, and the game runs silent. Call it once,
/// before any window or device is created.
pub const InitError = sdl_init.InitError;

pub fn init() InitError!void {
    try sdl_init.init();
}

/// Stops the platform and everything it started. Call it once, after every window, device, and
/// audio stream has been released. Open gamepads are closed first, while SDL is still running.
pub fn shutdown() void {
    sdl_input.releaseGamepads();
    sdl_init.shutdown();
}

/// Monotonic time and delays. The frame loop and the logger's timestamps both read this clock.
pub const clock = struct {
    /// Nanoseconds from an arbitrary fixed point. Only differences mean anything, and the value never
    /// goes backward.
    pub fn nowNs() u64 {
        return sdl_clock.nowNs();
    }

    /// Blocks the calling thread for at least `ms` milliseconds.
    pub fn sleepMs(ms: u32) void {
        sdl_clock.sleepMs(ms);
    }
};

/// File access. Every call names a location, and the platform decides which folder it resolves to.
/// Writes are accepted only for `.beside_executable`.
pub const files = struct {
    /// The folder the executable runs from, with a trailing separator. Valid until `shutdown`.
    pub fn baseDir() []const u8 {
        return sdl_files.baseDir();
    }

    /// Reads a whole file into memory that the caller owns. `error.NotFound` means the path does not exist.
    pub fn read(allocator: std.mem.Allocator, location: Location, path: []const u8) FileError![]u8 {
        return sdl_files.read(allocator, location, path);
    }

    /// Reads a whole file without logging, so a worker thread may call it. See sdl/files.zig `readQuiet`.
    pub fn readQuiet(allocator: std.mem.Allocator, location: Location, path: []const u8) FileError![]u8 {
        return sdl_files.readQuiet(allocator, location, path);
    }

    /// Writes a whole file via a temp file and atomic rename. Only `.beside_executable` accepts writes.
    pub fn write(location: Location, path: []const u8, bytes: []const u8) FileError!void {
        return sdl_files.write(location, path, bytes);
    }

    /// Deletes a file beside the executable. See sdl/files.zig `remove`.
    pub fn remove(location: Location, path: []const u8) FileError!void {
        return sdl_files.remove(location, path);
    }

    /// The full path for `path` at `location`, built in `buf`.
    pub fn absolutePath(location: Location, path: []const u8, buf: []u8) FileError![:0]const u8 {
        return sdl_files.absolutePath(location, path, buf);
    }

    /// The last modification time of a file, in nanoseconds since the Unix epoch, or null when the file
    /// can't be examined. Hot reload compares these to notice a change.
    pub fn modifiedNs(location: Location, path: []const u8) ?i64 {
        return sdl_files.modifiedNs(location, path);
    }

    /// Opens a file for reads at chosen offsets, so a stream can read it a piece at a time. `error.NotFound` means the
    /// path does not exist. Close the file with `close`.
    pub fn open(location: Location, path: []const u8) FileError!*types.OpenFile {
        return sdl_files.open(location, path);
    }

    /// Closes a file made by `open`.
    pub fn close(file: *types.OpenFile) void {
        sdl_files.close(file);
    }

    /// The size of an open file, in bytes.
    pub fn size(file: *types.OpenFile) FileError!u64 {
        return sdl_files.fileSize(file);
    }

    /// Reads up to `dst.len` bytes of an open file, starting at `offset`. Returns how many were read.
    pub fn readAt(file: *types.OpenFile, offset: u64, dst: []u8) FileError!usize {
        return sdl_files.readAt(file, offset, dst);
    }
};

/// Platform events and held keys, as the engine uses them.
pub const events = struct {
    /// The next event the engine consumes, or null when the queue has none left. Events the engine
    /// does not consume are skipped.
    pub fn poll() ?Event {
        return sdl_input.poll();
    }

    /// Whether a physical key is held, as of the latest query.
    pub fn isHeld(code: Scancode) bool {
        return sdl_input.isHeld(code);
    }
};

/// The game window. The engine holds a `*Window` and never sees the SDL type behind it.
pub const window = struct {
    /// Creates the game window. Panics if the platform cannot create one.
    pub fn create(title: [:0]const u8, width: c_int, height: c_int, fullscreen: bool) window_backend.CreateError!*Window {
        return try window_backend.create(title, width, height, fullscreen);
    }

    /// Destroys a window made by `create`.
    pub fn destroy(win: *Window) void {
        window_backend.destroy(win);
    }

    /// Switches the window between windowed and full screen.
    pub fn toggleFullscreen(win: *Window) void {
        window_backend.toggleFullscreen(win);
    }

    /// Starts SDL text input for an in-game development console.
    pub fn startTextInput(win: *Window) bool {
        return window_backend.startTextInput(win);
    }

    /// Stops SDL text input when the development console closes.
    pub fn stopTextInput(win: *Window) bool {
        return window_backend.stopTextInput(win);
    }

    /// The window's size in pixels. On high-DPI displays this is larger than its size in points.
    pub fn pixelSize(win: *Window) PixelSize {
        return window_backend.pixelSize(win);
    }

    /// Pixels per point. Mouse positions are in points, so the view mapping needs this.
    pub fn pixelDensity(win: *Window) f32 {
        return window_backend.pixelDensity(win);
    }
};

/// Playback devices and streams. Engine code gets opaque handles and `PcmFormat`, never SDL types.
/// Only the SDL backend knows what a handle holds.
pub const audio = struct {
    /// Opens the default playback device. Null when there is none, which is logged. The engine mixes in
    /// the returned format.
    pub fn openDefault() ?types.OpenedAudio {
        return sdl_audio.openDefault();
    }

    /// Closes a device. Streams bound to it must already be destroyed.
    pub fn closeDevice(device: *types.AudioDevice) void {
        sdl_audio.closeDevice(device);
    }

    /// A stream that takes and returns `format`. Its output converts to the device format when bound.
    pub fn createStream(format: types.PcmFormat) ?*types.AudioStream {
        return sdl_audio.createStream(format);
    }

    /// Binds a stream to a device so the device plays it.
    pub fn bindStream(device: *types.AudioDevice, stream: *types.AudioStream) bool {
        return sdl_audio.bindStream(device, stream);
    }

    /// Unbinds and frees a stream.
    pub fn destroyStream(stream: *types.AudioStream) void {
        sdl_audio.destroyStream(stream);
    }

    /// Queues bytes on a stream, in the stream's format.
    pub fn putStreamData(stream: *types.AudioStream, bytes: []const u8) bool {
        return sdl_audio.putStreamData(stream, bytes);
    }

    /// Pushes out whatever the stream still holds.
    pub fn flushStream(stream: *types.AudioStream) void {
        sdl_audio.flushStream(stream);
    }

    /// Sets the gain a stream plays at.
    pub fn setStreamGain(stream: *types.AudioStream, gain: f32) void {
        sdl_audio.setStreamGain(stream, gain);
    }

    /// Bytes queued on a stream as input.
    pub fn streamQueuedBytes(stream: *types.AudioStream) i32 {
        return sdl_audio.streamQueuedBytes(stream);
    }

    /// Converted bytes a stream holds ready to play.
    pub fn streamAvailableBytes(stream: *types.AudioStream) i32 {
        return sdl_audio.streamAvailableBytes(stream);
    }

    /// A stream that turns PCM from `src` into `dst`, with no device, for sound that is decoded a piece at a time. Bytes
    /// go in as `src` and come out as `dst`, and the stream keeps its resampling state between them. Free it with
    /// `destroyStream`.
    pub fn createConverter(src: types.PcmFormat, dst: types.PcmFormat) ?*types.AudioStream {
        return sdl_audio.createConverter(src, dst);
    }

    /// Copies converted bytes out of a stream into 16-byte-aligned `out`, as the converter may use SIMD sample writes.
    /// Returns how many bytes were copied, or -1 when the platform refuses.
    pub fn getStreamData(stream: *types.AudioStream, out: []align(16) u8) i32 {
        return sdl_audio.getStreamData(stream, out);
    }

    /// Decodes WAV bytes into PCM the caller owns. Needs no device.
    pub fn decodeWav(allocator: std.mem.Allocator, bytes: []const u8) types.AudioError!types.PcmBuffer {
        return sdl_audio.decodeWav(allocator, bytes);
    }

    /// Converts interleaved PCM between formats. Needs no device.
    pub fn convert(allocator: std.mem.Allocator, src: types.PcmFormat, bytes: []const u8, dst: types.PcmFormat) types.AudioError![]u8 {
        return sdl_audio.convert(allocator, src, bytes, dst);
    }
};

/// GPU device and frame operations. The underlying SDL types are confined to the backend and renderer.
pub const gpu = struct {
    pub const Device = sdl_gpu.Device;
    pub const TextureFormat = sdl_gpu.TextureFormat;
    pub const Gpu = sdl_gpu.Gpu;
    pub const Frame = sdl_gpu.Frame;

    pub fn waitIdle(device: *Device) void {
        sdl_gpu.waitIdle(device);
    }
};

/// SDL3's software/GPU accelerated 2D renderer backend.
pub const renderer2d = struct {
    pub const Renderer = sdl_renderer2d.Renderer;
    pub const CreateError = sdl_renderer2d.CreateError;

    pub fn create(win: *Window) CreateError!Renderer {
        return sdl_renderer2d.Renderer.init(win);
    }

    pub fn activate(renderer: *Renderer) void {
        sdl_renderer2d.activate(renderer);
    }

    pub fn deactivate() void {
        sdl_renderer2d.deactivate();
    }

    pub fn createTexture(width: u32, height: u32, pixels: []const u8) ?*Renderer2dTexture {
        return @ptrCast(@alignCast(sdl_renderer2d.createTexture(width, height, pixels)));
    }

    pub fn destroyTexture(texture: ?*Renderer2dTexture) void {
        sdl_renderer2d.destroyTexture(if (texture) |value| @ptrCast(@alignCast(value)) else null);
    }

    pub fn draw(
        texture: *Renderer2dTexture,
        src: anytype,
        dst: anytype,
        presentation_x: f32,
        presentation_y: f32,
        scale_x: f32,
        scale_y: f32,
        tint: [3]f32,
        alpha: f32,
        flip_x: bool,
        flip_y: bool,
        origin: [2]f32,
        rotation: f32,
    ) void {
        sdl_renderer2d.draw(
            @ptrCast(@alignCast(texture)),
            src.x, src.y, src.w, src.h,
            dst.x, dst.y, dst.w, dst.h,
            presentation_x, presentation_y, scale_x, scale_y,
            tint, alpha, flip_x, flip_y, origin[0], origin[1], rotation,
        );
    }
};
