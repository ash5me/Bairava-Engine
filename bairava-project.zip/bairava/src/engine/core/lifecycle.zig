//! Startup and shutdown of the engine's subsystems, in the order they depend on each other:
//! settings, SDL, the window, the GPU device, the native target and sprite batches, input, and audio.
//! `Session` owns all of them. It is built in place and never moved, because `Context` holds
//! pointers into it.

const std = @import("std");
const build_options = @import("build_options");
const allocator_types = @import("allocators.zig");
const platform = @import("../platform/platform.zig");
const audio = @import("../audio/audio.zig");
const logging = @import("../logging/log.zig");
const crash = @import("../logging/crash.zig");
const Input = @import("../input/input.zig").Input;
const diagnostics = @import("../diagnostics/collector.zig");
const hot_reload = @import("../assets/hot_reload.zig");
const startup = @import("startup.zig");
const Camera = @import("../renderer/camera.zig").Camera;
const sprite = @import("../renderer/sprite.zig");
const SpriteBatch = @import("../renderer/sprite.zig").SpriteBatch;
const post = @import("../renderer/post.zig");
const texture = @import("../renderer/texture.zig");
const Texture = @import("../renderer/texture.zig").Texture;
const settings = @import("settings.zig");
const application = @import("application.zig");
const context = @import("context.zig");
const capability = @import("../capabilities.zig");
const game_events = @import("game_events.zig");
const jobs = @import("../jobs/jobs.zig");
const staging = @import("../assets/staging.zig");
const texture_stream = @import("texture_stream.zig");

/// The most jobs the pool queues before a submit runs its job on the calling thread instead.
const job_queue_capacity: u32 = 256;

const Config = application.Config;
const Context = context.Context;
const max_full_path = context.max_full_path;
const elog = logging.scoped("engine");

/// Everything the running engine owns. `start` opens it and `stop` releases it.
pub const Session = struct {
    /// Text of the settings file. It is kept for the whole run, because the game reads from it.
    settings_bytes: ?[]u8 = null,
    engine_allocator: std.mem.Allocator = undefined,
    game_events: game_events.Queue = undefined,
    game_events_initialized: bool = false,
    platform_started: bool = false,
    window_created: bool = false,
    gpu_created: bool = false,
    renderer2d_created: bool = false,
    immediate_present_supported: bool = false,
    target_created: bool = false,
    world_batch_created: bool = false,
    post_chain_created: bool = false,
    screen_batch_created: bool = false,
    audio_created: bool = false,
    textures_ready: bool = false,
    stopped: bool = true,
    window: *platform.Window = undefined,
    gpu: platform.gpu.Gpu = undefined,
    renderer2d: platform.renderer2d.Renderer = undefined,
    /// The swapchain format. Targets and pipelines use it so they can be drawn into the window.
    format: platform.gpu.TextureFormat = undefined,
    /// The world target, sized to the view. The runtime rebuilds it when the view changes.
    target: Texture = undefined,
    world_batch: SpriteBatch = undefined,
    screen_batch: SpriteBatch = undefined,
    /// The effects that run between the world pass and the present pass. Empty unless the config names effects.
    post_chain: post.Chain = undefined,
    input: Input = .{},
    /// The step startup is on. After a failed start, it names the subsystem that failed. See startup.zig.
    stage: startup.Stage = .not_started,
    /// Frame timing, the published snapshot, and the debug overlay's switches and lines.
    collector: diagnostics.Collector = .{},
    /// Files watched for hot reload. Development builds poll them; release builds never do.
    reloads: hot_reload.Watcher = .{},
    audio: audio.Audio = undefined,
    cam: Camera = undefined,
    ctx: Context = undefined,
    /// Textures registered by name. It lives in the engine arena, so the context can point at it.
    textures: *context.TextureStore = undefined,
    /// Worker threads for background work. Created after the platform starts, and joined before the textures close.
    jobs_pool: jobs.Pool = undefined,
    jobs_started: bool = false,
    /// Decodes requested textures on the workers and uploads them on the main thread. See core/texture_stream.zig.
    streamer: texture_stream.Streamer = undefined,
    streamer_ready: bool = false,

    /// Opens everything, in dependency order: settings are read, then the platform starts, then the
    /// window, the GPU device, and the audio device. A failed step returns its error after releasing
    /// whatever was opened before it, so a failed start leaves the session stopped. The config is
    /// checked before anything is opened. GPU resources made once the device is up panic instead,
    /// because the engine cannot continue without them. Missing audio does not fail startup; the
    /// game runs silent.
    pub fn start(self: *Session, config: Config, allocators: *allocator_types.RuntimeAllocators) !void {
        logging.assert(self.stopped, @src(), "a session is already running", .{});
        config.validate() catch |err| {
            elog.err("{s}", .{Config.validationMessage(err)});
            return err;
        };
        self.engine_allocator = allocators.engineAllocator();
        self.game_events = game_events.Queue.init(self.engine_allocator);
        self.game_events_initialized = true;
        self.settings_bytes = readSettings(self.engine_allocator, config.settings_file);
        const settings_text: []const u8 = self.settings_bytes orelse "";
        applyLogLevel(settings_text);
        const window_settings = loadWindowSettings(settings_text, .{
            .width = config.window_w,
            .height = config.window_h,
            .fullscreen = config.fullscreen,
            .vsync = config.vsync,
        });

        self.stopped = false;
        errdefer self.stop();
        self.stage = .platform;
        try platform.init();
        self.platform_started = true;
        // SDL caches the executable's folder on first use. Asking for it here, before any worker can, keeps that
        // first use on the main thread.
        _ = platform.files.baseDir();
        self.jobs_pool = try jobs.Pool.init(config.worker_threads, job_queue_capacity);
        self.jobs_started = true;
        elog.info("job system: {d} worker thread(s)", .{self.jobs_pool.workerCount()});
        self.stage = .window;
        self.window = try platform.window.create(config.title, window_settings.width, window_settings.height, window_settings.fullscreen);
        self.window_created = true;
        elog.info("window {d}x{d}, native view {d}x{d}, {d} update steps per second", .{
            window_settings.width, window_settings.height, config.native_w, config.native_h, config.update_hz,
        });

        self.stage = .gpu;
        self.gpu = try platform.gpu.Gpu.init(self.window, build_options.gpu_debug);
        self.gpu_created = true;
        self.renderer2d = try platform.renderer2d.create(self.window);
        self.renderer2d_created = true;
        platform.renderer2d.activate(&self.renderer2d);
        self.immediate_present_supported = self.gpu.supportsImmediatePresent();
        const gpu_capabilities = capability.queryGpu(self.gpu.device, self.immediate_present_supported);
        if (capability.missingRequiredGpuFeature(gpu_capabilities)) |missing| {
            elog.err("GPU is missing required capability: {s}", .{@tagName(missing)});
            return error.UnsupportedGpuCapabilities;
        }
        if (!self.gpu.setVsync(window_settings.vsync)) elog.warn("immediate present is not available on this display, so vsync stays on", .{});
        const vsync_label: []const u8 = if (window_settings.vsync) "on" else "off";
        elog.info("vsync {s}", .{vsync_label});

        self.format = self.gpu.swapchainFormat();
        const gpu_debug_label: []const u8 = if (build_options.gpu_debug) "on" else "off";
        elog.info("GPU device ready, validation {s}, swapchain format {d}", .{ gpu_debug_label, self.format });

        const native_wf: f32 = @floatFromInt(config.native_w);
        const native_hf: f32 = @floatFromInt(config.native_h);
        self.stage = .targets;
        self.target = texture.createTarget(self.engine_allocator, self.gpu.device, config.native_w, config.native_h, self.format);
        self.target_created = true;
        self.world_batch = sprite.create(self.engine_allocator, self.gpu.device, self.format);
        self.world_batch_created = true;
        self.screen_batch = sprite.create(self.engine_allocator, self.gpu.device, self.format);
        self.screen_batch_created = true;
        // Effects are sized like the world target, and an empty list makes no GPU objects.
        self.post_chain = post.Chain.init(self.engine_allocator, self.gpu.device, self.format, config.post_effects, config.post_params, config.native_w, config.native_h);
        self.post_chain_created = true;
        // Sound output. A missing device leaves it silent, so it never stops the game.
        self.audio = audio.Audio.init();
        self.audio_created = true;
        // The game sets the world size every frame, so the camera starts without one.
        self.cam = Camera{ .view_w = native_wf, .view_h = native_hf, .world_w = 0, .world_h = 0 };
        // The store is allocated before the context, because the context points at it. Its loader reads
        // textures through the context, so the store is set up once the context exists.
        self.stage = .textures;
        self.textures = try self.engine_allocator.create(context.TextureStore);
        self.reloads.stat = hotReloadStamp;
        // Before the first frame is drawn, assume the view fills the window at its native size.
        self.ctx = Context{
            .gpu_state = @ptrCast(self.gpu.device),
            .allocators = allocators.context(),
            .input = &self.input,
            .event_reader = self.game_events.reader(),
            .scale_mode = config.scale_mode,
            .renderer = config.renderer,
            .zoom_min = config.zoom_min,
            .zoom_max = config.zoom_max,
            .layout = .{ .dst_w = native_wf, .dst_h = native_hf, .view_w = native_wf, .view_h = native_hf },
            .camera = &self.cam,
            .audio = &self.audio,
            .immediate_present_supported = self.immediate_present_supported,
            .settings_text = settings_text,
            .settings_file = config.settings_file,
            .textures = self.textures,
            .worker_allocator = config.allocator,
            .jobs = &self.jobs_pool,
            .diagnostics = &self.collector,
            .reloads = &self.reloads,
        };
        try self.textures.init(self.engine_allocator, context.max_registered_textures, context.textureLoader(&self.ctx));
        self.textures.setBudget(config.texture_budget_bytes);
        self.textures_ready = true;
        self.streamer = texture_stream.Streamer.init(
            &self.jobs_pool,
            staging.packagedReader(),
            config.allocator,
            config.texture_staging_budget_bytes,
        );
        self.streamer_ready = true;
        self.stage = .ready;
    }

    /// Releases everything `start` opened, in reverse order: the audio device, the batches, the
    /// target, the GPU, the window, and then the platform. The game must be released first.
    pub fn stop(self: *Session) void {
        if (self.stopped) return;
        self.stopped = true;

        if (self.game_events_initialized) {
            self.game_events.deinit();
            self.game_events_initialized = false;
        }
        if (self.audio_created) {
            self.audio.deinit();
            self.audio_created = false;
        }
        if (self.post_chain_created) {
            self.post_chain.deinit();
            self.post_chain_created = false;
        }
        if (self.screen_batch_created) {
            self.screen_batch.deinit();
            self.screen_batch_created = false;
        }
        if (self.world_batch_created) {
            self.world_batch.deinit();
            self.world_batch_created = false;
        }
        if (self.target_created) {
            self.target.deinit();
            self.target_created = false;
        }
        // Decodes still running read the pool and write into the streamer, so both finish before either is released.
        if (self.streamer_ready) {
            self.streamer.deinit();
            self.streamer_ready = false;
        }
        if (self.jobs_started) {
            self.jobs_pool.deinit();
            self.jobs_started = false;
        }
        if (self.textures_ready) {
            // Textures hold GPU objects, so they go before the device. The game was released first, so
            // nothing still in use is dropped here. The counters are logged as the store closes.
            const counts = self.textures.stats();
            elog.info("texture store at shutdown: {d} hits, {d} misses, {d} failed loads, {d} still loaded", .{
                counts.hits, counts.misses, counts.failed_loads, counts.loaded,
            });
            self.textures.deinit();
            self.textures_ready = false;
        }
        if (self.renderer2d_created) {
            platform.renderer2d.deactivate();
        }
        if (self.renderer2d_created) {
            self.renderer2d.deinit();
            self.renderer2d_created = false;
        }
        if (self.gpu_created) {
            // The device must go before the window, because it is still claimed for that window.
            self.gpu.deinit();
            self.gpu_created = false;
        }
        if (self.window_created) {
            platform.window.destroy(self.window);
            self.window_created = false;
        }
        if (self.platform_started) {
            platform.shutdown();
            self.platform_started = false;
        }
        if (self.settings_bytes) |bytes| {
            self.engine_allocator.free(bytes);
            self.settings_bytes = null;
        }
    }
};

/// Reads the `log_level` line of the settings file, which sets the lowest level written. A value that is not a
/// level name is logged, and the default is kept. Runs before anything else is logged at a level that matters.
fn applyLogLevel(text: []const u8) void {
    var lines = settings.Lines.init(text);
    while (lines.next()) |line| {
        if (!std.mem.eql(u8, line.key, "log_level")) continue;
        const value = line.value orelse {
            elog.warn("settings line {d}: 'log_level' needs a value: trace, debug, info, warn, or error", .{line.number});
            continue;
        };
        logging.min_level = logging.parseLevel(value) orelse {
            elog.warn("settings line {d}: '{s}' is not a log level (trace, debug, info, warn, or error), so the default is kept", .{ line.number, value });
            continue;
        };
    }
}

/// The modification time of a packaged asset, for the hot reload watcher. Watched assets are packaged.
fn hotReloadStamp(path: []const u8) ?i64 {
    return platform.files.modifiedNs(.packaged, path);
}

/// Opens the log file beside the executable when the game asks for one. Each run replaces the
/// file from the last run. Startup messages and startup failures are kept, so this runs first.
pub fn openLog(config: Config) void {
    if (config.crash_file) |name| setupCrashReport(name);
    if (config.log_file) |name| {
        var path_buf: [max_full_path]u8 = undefined;
        const path = platform.files.absolutePath(.beside_executable, name, &path_buf) catch {
            elog.warn("log file name is longer than {d} bytes, so logs go to the terminal only", .{max_full_path});
            return;
        };
        if (logging.openFile(path)) {
            elog.info("log file {s}", .{path});
        } else {
            elog.warn("could not open log file {s}, so logs go to the terminal only", .{path});
        }
    }
}

/// Sets the file a crash report is written to, beside the executable, and clears the report from an earlier run.
fn setupCrashReport(name: [:0]const u8) void {
    var path_buf: [max_full_path]u8 = undefined;
    const path = platform.files.absolutePath(.beside_executable, name, &path_buf) catch {
        elog.warn("crash report name is longer than {d} bytes, so crash reports are not written", .{max_full_path});
        return;
    };
    if (!crash.setReportPath(path)) {
        elog.warn("crash report path {s} is too long, so crash reports are not written", .{path});
        return;
    }
    crash.clearOldReport();
}

/// Reads the settings file beside the executable. Returns null when there is no file, or it can't be
/// read. The caller frees the result with the supplied engine allocator.
fn readSettings(allocator: std.mem.Allocator, name: []const u8) ?[]u8 {
    var buf: [max_full_path]u8 = undefined;
    const shown = platform.files.absolutePath(.beside_executable, name, &buf) catch {
        elog.warn("settings file name '{s}' is too long, so the defaults are used", .{name});
        return null;
    };
    const bytes = platform.files.read(allocator, .beside_executable, name) catch |err| {
        switch (err) {
            error.NotFound => elog.info("no settings file at {s}, so the defaults are used", .{shown}),
            else => elog.warn("settings file {s} could not be read, so the defaults are used", .{shown}),
        }
        return null;
    };
    elog.info("settings file {s}", .{shown});
    return bytes;
}

/// Reads the window settings over `defaults`. A value that can't be read is logged, and its default is kept.
fn loadWindowSettings(text: []const u8, defaults: settings.Window) settings.Window {
    var window = defaults;
    var lines = settings.Lines.init(text);
    while (lines.next()) |line| {
        const value = line.value orelse continue;
        if (settings.applyWindowLine(&window, line.key, value) == .bad_value) {
            elog.warn("settings line {d}: '{s}' has a value that isn't valid, so the default is used", .{ line.number, line.key });
        }
    }
    return window;
}

test "stopping an unstarted session is idempotent" {
    var session = Session{};
    session.stop();
    session.stop();
    try std.testing.expect(session.stopped);
}
